<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Article App</title>

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
    </head>
    <body>
        <div id="app"></div>
    </body>
</html><?php /**PATH F:\projects\laravel-react\resources\views/app.blade.php ENDPATH**/ ?>