import { Container } from "@mui/material";
import React from "react";
import Form from "./../Form/Form";
import DataTable from "./../Data/DataTable";

function DefaultView() {
    

    return (
        <Container>
            <Form />
            <DataTable />
        </Container>
        
    )
}

export default (DefaultView)