import React, {useState, useEffect} from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import {Box, Button} from "@mui/material";

const rows = [
    {
        name: "banan",
        address: "abricos",
        email: "email@gmail.com",
        message: "gfy"
    }
];

export default function DataTable() {

    const [tableData, setTableData] = useState([]);

    const fetchData = async () => {
        await fetch('/api/quotes')
            .then(response => response.json())
            .then(data => { setTableData(data.data) })
    }
    
    useEffect(() => {
        fetchData();
    },[])

    
    return (
        <>
        <Box component="span" sx={{ p: 2, pl:0 }}>
            <Button variant="contained" onClick={fetchData}>Reload Data</Button>
        </Box>
            
        <TableContainer component={Paper} sx={{mt: 2}}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Address</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Message</TableCell>
                </TableRow>
                </TableHead>
                <TableBody>
                {tableData.map((row, index) => (
                    <TableRow
                    key={index}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                    <TableCell component="th" scope="row">
                        {row.name}
                    </TableCell>
                    <TableCell align="left">{row.address}</TableCell>
                    <TableCell align="left">{row.email}</TableCell>
                    <TableCell align="left">{row.message}</TableCell>
                    </TableRow>
                ))}
                </TableBody>
            </Table>
        </TableContainer>
      </>
  );
}
